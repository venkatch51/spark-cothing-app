// import { render, screen } from '@testing-library/react'
import App from './App'

it('has proper App Component', () => {
  expect(App).toBeTruthy()
})
