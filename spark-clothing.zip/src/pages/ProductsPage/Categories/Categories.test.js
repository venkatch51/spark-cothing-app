import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import Categories from './Categories';
import { ProductContext,ProductProvider } from '../../../contexts/ProductContext';
import axios from 'axios';

jest.mock('axios');
describe('Categories', () => {
  it('should click on All titled link', () => {
    axios.get.mockResolvedValueOnce({
      data: [{}],
      status: 200
    });
    const contextValue = {};
    render(
      <ProductProvider value={contextValue}>
        <Categories />
      </ProductProvider>
    );
    const component = screen.getByText('All');
    fireEvent.click(component);
  });
});
